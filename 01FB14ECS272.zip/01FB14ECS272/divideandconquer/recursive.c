#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void free_mem(float **a, int n){
	for(int i = 0; i < n; ++i)
		free((void*)a[i]);
	free((void**)a);
	
}

float** assign_matrix_mem(int n){
	
	float **c = (float**)malloc(sizeof(float*)*n);
	for(int i = 0; i < n; ++i)
		c[i] = (float*)malloc(sizeof(float)*n);
	
	return c;
}

float **add_matrix(float **a, float **b, int n){
	for(int i = 0; i < n; ++i)
		for(int j = 0; j < n; ++j)
			a[i][j] = a[i][j] + b[i][j];
			
	free_mem(b,n);
	
	return a;
}

float** rec_matrix_mul(float **a, float **b, int a_rs, int a_cs, int b_rs, int b_cs, int n){
	float prod = 0;
	float **res;
	
	if(n == 1){
	
		res = assign_matrix_mem(n);
		res[0][0] = a[a_rs][a_cs]*b[b_rs][b_cs];
	}
	else{
		int m = n/2;
		float **res1, **res2, **res3, **res4;
		
		res1 = add_matrix(rec_matrix_mul(a, b, a_rs, a_cs, b_rs, b_cs, m),  //1,1		 
		 				rec_matrix_mul( a, b, a_rs, a_cs + m, b_rs + m, b_cs, m), //2,3
		 				m);
		 
		res2 = add_matrix(rec_matrix_mul(a, b, a_rs, a_cs, b_rs, b_cs + m, m),  //1,2
		 				rec_matrix_mul(a, b, a_rs, a_cs + m, b_rs + m,b_cs+ m, m),  //2,4	
		 				m);
		 
		res3 = add_matrix(rec_matrix_mul(a, b, a_rs + m, a_cs, b_rs, b_cs, m), //3,1
		 				rec_matrix_mul(a, b, a_rs + m, a_cs + m, b_rs + m, b_cs, m), //4,3
		 				m);
		 
		res4 = add_matrix(rec_matrix_mul(a, b, a_rs + m, a_cs, b_rs, b_cs +m, m), //3,2
		 				rec_matrix_mul(a, b, a_rs + m, a_cs + m, b_rs +m, b_cs + m, m), //4,4
						m);
		 
		res = assign_matrix_mem(n);
		//getting the res
		for(int i = 0; i < m; ++i){
		
			for(int j = 0; j < m; ++j){
				res[i][j] = res1[i][j];
				res[i][j + m] = res2[i][j];
				res[m + i][j] = res3[i][j];
				res[m + i][j + m] = res4[i][j];
			}
		}
		
		free_mem(res1, m);
		free_mem(res2, m);
		free_mem(res3, m);
		free_mem(res4, m);
	
	}
	
	
	return res;
}

void matrix_mul(float **a, float **b, float **res, int n){
	float **r =	rec_matrix_mul(a,b,0,0,0,0,n);
	
	for(int i = 0; i < n; ++i)
		for(int j = 0; j < n; ++j)
			res[i][j] = r[i][j];
			
	free_mem(r, n);
}

void display(float **m, int n){
	for(int i = 0; i < n; ++i){
		for(int j = 0; j < n; ++j)
			printf("%.2f ",m[i][j]);
		printf("\n");
	}
	printf("\n");
}

float diff_time(struct timespec *start, struct timespec *end){
		
		return (end->tv_sec - start->tv_sec) + (end->tv_nsec - start->tv_nsec)/1000000000.00;	
}

int main(){
	struct timespec start, end;
	
	float **a;
	float **b;
	float **c;
	int n;
	char buffer[32];
	clock_gettime(CLOCK_REALTIME, &start);
	FILE *f;
	printf("Enter the input file: ");
	scanf("%s", buffer);
	f = fopen(buffer, "r");
	fscanf(f,"%d",&n);
	
	a = (float**)malloc(sizeof(float*)*n);
	b = (float**)malloc(sizeof(float*)*n);
	c = (float**)malloc(sizeof(float*)*n);
	
	for(int i = 0; i < n; ++i) c[i] = (float*)malloc(sizeof(float)*n);
	
	for(int i = 0; i < n; ++i){
		a[i] = (float*)malloc(sizeof(float)*n);
		for(int j = 0; j < n; ++j)
			fscanf(f, "%f", &a[i][j]);	
	
	}
	fgetc(f);
	
	for(int i = 0; i < n; ++i){
		b[i] = (float*)malloc(sizeof(float)*n);
		for(int j = 0; j < n; ++j){
			fscanf(f, "%f", &b[i][j]);
		}
	
	}
	
	matrix_mul(a, b, c, n);
	//display(a,n);
	//display(b,n);
	display(c,n);
	
	clock_gettime(CLOCK_REALTIME,&end);
	
	printf("Time Elapsed: %f s\n", diff_time(&start,&end));	
	
	for(int i = 0; i < n; ++i){
		free(a[i]); free(b[i]); free(c[i]);
	}
	free(a);
	free(b);
	free(c);
	return 0;
}
