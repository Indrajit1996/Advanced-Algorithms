// Answer to 1st question
 
#include<stdio.h>
 #include<stdlib.h>
int main(){

  float a[5][5],b[5][5];
int   m,n,o,p,i,j;
  printf("\nEnter the row and column of first matrix");
  scanf("%d %d",&m,&n);
  printf("\nEnter the row and column of second matrix");
  scanf("%d %d",&o,&p);
  if(n!=o){
      printf("Matrix mutiplication is not possible");
      printf("\nColumn of first matrix must be same as row of second matrix");
  }
  else{
      
      
      printf("\nThe First matrix is\n");
      for(i=0.0;i<m;i++){
      printf("\n");
      for(j=0.0;j<n;j++){
          a[i][j] = rand()%100 + 1;
           printf("%1f\t",a[i][j]);
      }
      }
      printf("\nThe Second matrix is\n");
      for(i=0;i<o;i++){
      printf("\n");
      for(j=0;j<p;j++){
        b[i][j] = rand()%100 +1;
        
        printf("%1f\t",b[i][j]);
      }       
      }
  
  }
  return 0;
}
