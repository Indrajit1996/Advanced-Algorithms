#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <assert.h>

void display(float **m, int n){
	for(int i = 0; i < n; ++i){
		for(int j = 0; j < n; ++j)
			printf("%.2f ",m[i][j]);
		printf("\n");
	}
	printf("\n");
}


void free_mem(float **a, int n){
	for(int i = 0; i < n; ++i)
		free((void*)a[i]);
	free((void**)a);
	
}

float** assign_matrix_mem(int n){
	
	float **c = (float**)malloc(sizeof(float*)*n);
	for(int i = 0; i < n; ++i)
		c[i] = (float*)malloc(sizeof(float)*n);
	
	return c;
}

void ** add_matrix(float **a, float **b, float **c, int a_rs, int a_cs, int b_rs, int b_cs, int n){
	for(int i = 0; i < n; ++i)
		for(int j = 0; j < n; ++j)
			c[i][j] = a[a_rs + i][a_cs + j] + b[b_rs + i][b_cs + j];

}

void **sub_matrix(float **a, float **b, float **c, int a_rs, int a_cs, int b_rs, int b_cs, int n){
	for(int i = 0; i < n; ++i)
		for(int j = 0; j < n; ++j)
			c[i][j] = a[a_rs + i][a_cs + j] - b[b_rs + i][b_cs + j];
	
}

float** strassen_mul(float **a, float **b, int a_rs, int a_cs, int b_rs, int b_cs, int n){
	float prod = 0;
	float **res;
	
	if(n == 1){
	
		res = assign_matrix_mem(n);
		res[0][0] = a[a_rs][a_cs]*b[b_rs][b_cs];
	}
	else{
	
		int m = n/2;
		
		float **s[10];
		float **p[7];
		for(int i = 0; i < 10; ++i)
			s[i] = assign_matrix_mem(m);
			
			assert(b);
			sub_matrix(b, b, s[0], b_rs, b_cs + m, b_rs + m, b_cs + m, m);  // s[0]
			add_matrix(a, a, s[1], a_rs, a_cs, a_rs, a_cs + m, m);  // s[1]
			add_matrix(a, a, s[2], a_rs + m, a_cs, a_rs + m, a_cs + m, m);  // s[2]
			sub_matrix(b, b, s[3], b_rs + m, b_cs, b_rs, b_cs , m);  // s[3]
			add_matrix(a, a, s[4], a_rs, a_cs, a_rs + m, a_cs + m, m);  // s[4]
			add_matrix(b, b, s[5], b_rs, b_cs, b_rs + m, b_cs + m, m);  // s[5]
			sub_matrix(a, a, s[6], a_rs, a_cs + m, a_rs + m, a_cs + m, m);  // s[6]
			add_matrix(b, b, s[7], b_rs + m, b_cs, b_rs + m, b_cs + m, m); // s[7]
			sub_matrix(a, a, s[8], a_rs, a_cs, a_rs + m, a_cs, m);  // s[8]
			 add_matrix(b, b, s[9], b_rs, b_cs, b_rs, b_cs + m, m);  // s[9]
				
		p[0] = strassen_mul( a, s[0], a_rs, a_cs, 0, 0, m);
		p[1] = strassen_mul(	s[1], b, 0, 0, b_rs + m, b_cs + m, m);
		p[2] = strassen_mul(	s[2], b, 0, 0, b_rs, b_cs, m);
		p[3] = strassen_mul(	a, s[3], a_rs + m, a_cs + m, 0, 0, m);
		p[4] = strassen_mul(	s[4], s[5], 0, 0, 0, 0, m);
		p[5] = strassen_mul(	s[6], s[7], 0, 0, 0, 0, m);
		p[6] = strassen_mul( s[8], s[9], 0, 0, 0, 0, m);
		
		
		add_matrix(p[4], p[3], s[0], 0, 0, 0, 0, m);
		sub_matrix(p[5], p[1], s[1], 0, 0, 0, 0, m);
		add_matrix(s[0], s[1], s[0], 0, 0, 0, 0, m); // s[0] c11
		
		add_matrix(p[0], p[1], s[1], 0, 0, 0, 0, m); //s[1] c12 
		
		add_matrix(p[2], p[3], s[2], 0, 0, 0, 0, m); //s[2] c21
		sub_matrix(p[4], p[2], s[3], 0, 0, 0, 0, m);
		sub_matrix(p[0], p[6], s[4], 0, 0, 0, 0, m);	
		add_matrix(s[3], s[4], s[3], 0, 0, 0, 0, m); //s[3] c22
		
		res = assign_matrix_mem(n);
		
		for(int i= 0; i < m; ++i){
			for(int j = 0; j < m; ++j){
				res[i][j] = s[0][i][j];
				res[i][j+m] = s[1][i][j];
				res[i+m][j] = s[2][i][j];
				res[i+m][j+m] = s[3][i][j];	
			
			}
		}
				
		
		for(int i = 0; i < 10; ++i)
			free_mem(s[i], m);
			
		for(int i = 0; i < 7; ++i)
			free_mem(p[i], m);
		
		
	}
	
	
	return res;
}

void matrix_mul(float **a, float **b, float **res, int n){
	float **r =	strassen_mul(a,b,0,0,0,0,n);
	
	for(int i = 0; i < n; ++i)
		for(int j = 0; j < n; ++j)
			res[i][j] = r[i][j];
			
	free_mem(r, n);
}


float diff_time(struct timespec *start, struct timespec *end){
		
		return (end->tv_sec - start->tv_sec) + (end->tv_nsec - start->tv_nsec)/1000000000.00;	
}

int main(){
	struct timespec start, end;
	
	float **a;
	float **b;
	float **c;
	int n;
	char buffer[32];
	clock_gettime(CLOCK_REALTIME, &start);
	FILE *f;
	printf("Enter the input file: ");
	scanf("%s", buffer);
	f = fopen(buffer, "r");
	fscanf(f,"%d",&n);
	
	a = (float**)malloc(sizeof(float*)*n);
	b = (float**)malloc(sizeof(float*)*n);
	c = (float**)malloc(sizeof(float*)*n);
	
	for(int i = 0; i < n; ++i) c[i] = (float*)malloc(sizeof(float)*n);
	
	for(int i = 0; i < n; ++i){
		a[i] = (float*)malloc(sizeof(float)*n);
		for(int j = 0; j < n; ++j)
			fscanf(f, "%f", &a[i][j]);	
	
	}
	fgetc(f);
	
	for(int i = 0; i < n; ++i){
		b[i] = (float*)malloc(sizeof(float)*n);
		for(int j = 0; j < n; ++j){
			fscanf(f, "%f", &b[i][j]);
		}
	
	}
	
	matrix_mul(a, b, c, n);
	//display(a,n);
	//display(b,n);
	display(c,n);
	
	clock_gettime(CLOCK_REALTIME,&end);
	
	printf("Time Elapsed: %f s\n", diff_time(&start,&end));	
	
	for(int i = 0; i < n; ++i){
		free(a[i]); free(b[i]); free(c[i]);
	}
	free(a);
	free(b);
	free(c);
	return 0;
}
